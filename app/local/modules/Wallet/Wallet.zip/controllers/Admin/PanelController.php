<?php 
class Wallet_Admin_PanelController extends Admin_Controller_Default
{


}
