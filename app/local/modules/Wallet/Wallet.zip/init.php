<?php
$init = function($bootstrap) {
    Nwicode_Module::addEditorMenu("Wallet", "wallet", __("Wallet"), "wallet/admin/panel","fa fa-university");
}; 