<?php

/**
 * Class Wallet_Model_Db_Table_PaymentHistory
 */
class Wallet_Model_Db_Table_PaymentHistory extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet_payment_history';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_payment_history_id';
    
}