<?php

/**
 * Class Wallet_Model_Db_Table_PayoutRequest
 */
class Wallet_Model_Db_Table_PayoutRequest extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet_payout_request';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_payout_request_id';
    
}