<?php

/**
 * Class Wallet_Model_Db_Table_PayoutMethods
 */
class Wallet_Model_Db_Table_PayoutMethods extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet_payout_methods';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_payout_methods_id';
    
}