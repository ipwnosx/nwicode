<?php

/**
 * Class Wallet_Model_Db_Table_PaymentSystem
 */
class Wallet_Model_Db_Table_PaymentSystems extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet_payment_systems';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_payment_systems_id';
    
}