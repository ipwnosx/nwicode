<?php

/**
 * Class Wallet_Model_Db_Table_Customer
 */
class Wallet_Model_Db_Table_Customer extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet_customer';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_customer_id';
    
}