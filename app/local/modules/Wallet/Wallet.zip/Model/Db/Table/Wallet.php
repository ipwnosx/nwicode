<?php

/**
 * Class Wallet_Model_Db_Table_Wallet
 */
class Wallet_Model_Db_Table_Wallet extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_id';
    
}