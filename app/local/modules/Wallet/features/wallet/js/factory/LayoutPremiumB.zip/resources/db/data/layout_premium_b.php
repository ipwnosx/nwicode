<?php
$defined_options = array(
	"header_background_color" =>"#FC5241",
	"slogan_text_1" => "Premium B",
	"slogan_text_2" => "App Layout",
	"slogan_text_3" => "Premium B",
	"slogan_text_1_color" => "#e0e0e0",
	"slogan_text_2_color" => "#e0e0e0",
	"slogan_text_3_color" => "#FFFFFF",
	"header_title_top_color" => "#c04c4c",
	"header_title_bottom_color" => "#c04c4c",
	"menu_button_class" => "ion-navicon-round",
	"header_bar_color" => "#FFFFFF",
	"sidemenu_background_color"=>"#333333",
	"sidemenu_text_color"=>"#f0f0f0",
	"sidemenu_text_item_color"=>"#f0f0f0",
	"sidemenu_header_text"=>"",
	"sidemenu_text_font_size"=>"14px",
	"show_account_icon"=>"yes",
	"show_wallet_icon"=>"yes",
	"show_account_icon_class_unlogged" => "ion-locked",
	"show_account_icon_class_logged" => "ion-person",
	"show_wallet_icon_class" => "ion-card",
/*	"slogan_text_1_weight" => "700",
	"slogan_text_2_weight" => "300",
	"features_text_case" => "uppercase",
	"features_text_color" => "#ffffff",
	"side_text_case" => "none",
	"side_text_color" => "#ffffff",
	"lbackground_color" => "#1d202d",
	"welcome_user_text_color" => "#ffffff",
	"welcome_text_color" => "#10cf7f",
	"bullet_background_color" => "#10cf7f",
	"side_border_bottom_color" => "#19da89",
	"side_background_color_start" => "#1e3d3c",
	"side_background_color_end" => "#33d691",
	"menu_title_color" => "#FFFFFF",
	"menu_title_color" => "#FFFFFF",
	"menu_button_class" => "ion-navicon-round",
	
	"slide3_enable"=>"1",
	"slide2_enable"=>"1",
	"slider_auto_play"=>"1",
	"slider_touch_slide"=>"1",
	"slider_show_bullets"=>"1",
			
	"slider1_title"=>"Demo slide 1",
	"slider1_subtitle"=>"Slide 1 subtitle",
	"slider1_text"=>"Simple text illustrate.",
	"slider1_title_color"=>"#33d691",
	"slider1_subtitle_color"=>"#10cf7f",
	"slider1_text_color"=>"#ffffff",
	"slider1_show_caption"=>"1",
	"slide1_img" => "",
	"slide1_rich"=>"",
	
	"slider2_title"=>"Demo slide 2",
	"slider2_subtitle"=>"Slide 2 subtitle",
	"slider2_text"=>"Simple text illustrate.",
	"slider2_title_color"=>"#33d691",
	"slider2_subtitle_color"=>"#10cf7f",
	"slider2_text_color"=>"#ffffff",
	"slider2_show_caption"=>"1",
	"slide2_enable"=>"1",
	"slide2_img" => "",
	"slide2_rich"=>"",
	
	"slider3_title"=>"Demo slide 3",
	"slider3_subtitle"=>"Slide 3 subtitle",
	"slider3_text"=>"Simple text illustrate.",
	"slider3_title_color"=>"#33d691",
	"slider3_subtitle_color"=>"#10cf7f",
	"slider3_text_color"=>"#ffffff",
	"slider3_show_caption"=>"1",
	"slide3_enable"=>"1",
	"slide3_img" => "",
	"slide3_rich"=>"",*/
);
/*
for($i=4;$i<=10;$i++) {
	$defined_options[]="";
	$defined_options["slider".$i."_title"]="Demo slide ".$i."";
	$defined_options["slider".$i."_subtitle"]="Slide ".$i." subtitle";
	$defined_options["slider".$i."_text"]="Simple text illustrate.";
	$defined_options["slider".$i."_title_color"]="#33d691";
	$defined_options["slider".$i."_subtitle_color"]="#10cf7f";
	$defined_options["slider".$i."_text_color"]="#ffffff";
	$defined_options["slider".$i."_show_caption"]="1";
	$defined_options["slide".$i."_enable"]="0";
	$defined_options["slide".$i."_img"] = "";
	$defined_options["slide".$i."_rich"]="";
}*/

$default_options = Nwicode_Json::encode($defined_options);




$datas = array(
    'name' => 'Layout Premium B',
    'visibility' => Application_Model_Layout_Homepage::VISIBILITY_HOMEPAGE,
    'code' => 'layout_premium_b',
    'preview' => '/customization/layout/homepage/layout_premium_b.png',
	'preview_new' => '/customization/layout/homepage/layout_premium_b_modal.png',
    'use_more_button' => 0,
    'use_horizontal_scroll' => 0,
    'number_of_displayed_icons' => 198,
    'position' => "bottom",
    "order" => 1210,
    "can_uninstall" => 1,
    "is_active" => 1,
	'options' => $default_options
);

$layout = new Application_Model_Layout_Homepage();
$layout
    ->setData($datas)
    ->insertOrUpdate(array("code"));

Nwicode_Assets::copyAssets("/app/local/modules/LayoutPremiumB/resources/var/apps/");