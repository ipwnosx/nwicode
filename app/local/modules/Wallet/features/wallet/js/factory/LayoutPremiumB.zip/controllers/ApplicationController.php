<?php

class LayoutPremiumB_ApplicationController extends Application_Controller_Default
{
  
  protected $_logger;

  // controller actions that trigger clearing of cache
  public $cache_triggers = array(
                            "formoptions" => array(
                                "tags" => array("app_#APP_ID#")
                              )
                            );

  protected function moveFileToHomepageLayoutDir($file, $layout_code)
  {
    $uploaded_filename = $file;
    $uploaded_folder = Core_Model_Directory::getTmpDirectory(true) . '/';
    $destination_folder = Core_Model_Directory::getBasePathTo("") . "/images/application/homepage_layout/" . $layout_code . "/";
    if (!is_dir($destination_folder)) {
      mkdir($destination_folder, 0777, true);
    }

    return copy($uploaded_folder.$uploaded_filename, $destination_folder.$uploaded_filename);
  }

  // edit module option via nwicode
  public function formoptionsAction()
  {
    $this->_logger = Zend_Registry::get("logger");
	if ($datas = $this->getRequest()->getPost()) {
		
      $application = $this->getApplication();
      $layout_id = $application->getLayoutId();
      $layout_model = new Application_Model_Layout_Homepage();
      $layout = $layout_model->find($layout_id);
      $layout_code = 'layout_premium_b';

      if ($options = Nwicode_Feature::getLayoutOptionsCallbacks($layout_code)) {
        $options = Nwicode_Feature::getLayoutOptionsCallbacks($layout_code);
        $form_class = $options["form"];
        $form = new $form_class($layout);
      } else {
        $form = new Nwicode_Form_Options($layout);
      }

      if ($form->isValid($datas)) {

		
		//$this->_logger->info(Nwicode_Json::encode($datas,JSON_UNESCAPED_UNICODE));
		if (!empty($datas['sidemenu_header_text'])) $datas['sidemenu_header_text']=base64_encode($datas['sidemenu_header_text']); 
		
		$application->setLayoutOptions(Nwicode_Json::encode($datas,JSON_UNESCAPED_UNICODE));
		$application->save();

		$html = array(
		"success" => 1,
		"message" => __("Options saved"),
		"datas" => $toto
		);
      } else {
        $html = array(
          "error" => 1,
          "message" => $form->getTextErrors(),
          "errors" => $form->getTextErrors(true)
        );
      }

      $this->_sendHtml($html);
    }
  }
}
