<?php
class LayoutPremiumB_Bootstrap {

    public static function init($bootstrap) {
        # Register assets
        Nwicode_Assets::registerAssets("LayoutPremiumB", "/app/local/modules/LayoutPremiumB/resources/var/apps/");
        Nwicode_Assets::addJavascripts(array(
            "modules/layout/home/layout_premium_b/hooks.js",
        ));
        Nwicode_Assets::addStylesheets(array(
            "modules/layout/home/layout_premium_b/style.css",
        ));
		Nwicode_Feature::registerLayoutOptionsCallbacks("layout_premium_b", "LayoutPremiumB_Form_LayoutPremiumBOptions", function($datas) {
			$options = array();

			return $options;
		});		
    }
}
