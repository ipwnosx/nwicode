<?php
class LayoutPremiumB_Form_LayoutPremiumBOptions extends Nwicode_Form_Options_Abstract {


    public function init() {
        parent::init();

		$this->setAction(__path("/layoutpremiumb/application/formoptions"))
         ->setAttrib("id", "form-options");
	
		
        /** Bind as a create form */
        self::addClass("create", $this);
        self::addClass("form-layout-options", $this);

       $this->setDisplayGroupDecorators(array(
            'FormElements',
            'Fieldset'
        ));		
		
		//header
		$this->addSectionSeparator(__("Header settings"));
		$this->addSimpleText("slogan_text_1", __("Title in header")); 
		$this->addSimpleText("slogan_text_2", __("Subtitle in header")); 
		$this->addSimpleText("slogan_text_3", __("Top Title in header")); 
		$this->addSimpleText("header_background_color", __("Header Background Color"))->addClass("jscolor"); 
		$this->addSimpleText("header_title_top_color", __("Title Top Border color"))->addClass("jscolor"); 
		$this->addSimpleText("header_title_bottom_color", __("Title Bottom Border color"))->addClass("jscolor"); 
		$this->addSimpleText("slogan_text_1_color", __("Title color"))->addClass("jscolor"); 
		$this->addSimpleText("slogan_text_2_color", __("Subtitle color"))->addClass("jscolor"); 
		$this->addSimpleText("slogan_text_3_color", __("Top Title color"))->addClass("jscolor");
		$this->addSimpleText("menu_button_class", __("Menu button icon"));
		$this->addSimpleText("show_account_icon_class_logged", __("Auth account icon"));
		$this->addSimpleText("show_account_icon_class_unlogged", __("Unauth account icon"));
		$this->addSimpleText("header_bar_color", __("Header buttons color"));
		$this->addSimpleSelect("show_account_icon", __("Show account icon"), array("yes"=>__("Yes"), "no" => __("No")));
		$this->addSimpleSelect("show_wallet_icon", __("Show wallet info in header"), array("yes"=>__("Yes"), "no" => __("No")));
		$this->addSimpleText("show_wallet_icon_class", __("Wallet icon"));

		//menu
		$this->addSectionSeparator(__("Menu setting"));
		$this->addSimpleText("sidemenu_background_color", __("Sidemenu background color"));
		$this->addSimpleText("sidemenu_text_color", __("Sidemenu text color"));
		$this->addSimpleText("sidemenu_text_font_size", __("Sidemenu item font size"));
		$richtext1 = $this->addSimpleTextarea('sidemenu_header_text', __('Sidemenu text'));
		$richtext1->setRichtext();		
		
		$this->addSimpleHtml("css",'
			<script type="text/javascript">
				$(".sb-cb").css("clear","both");
				$("#header_background_color").addClass("jscolor");
				$("#header_title_top_color").addClass("jscolor");
				$("#header_title_top_color").addClass("jscolor");
				$("#header_title_bottom_color").addClass("jscolor");
				$("#slogan_text_1_color").addClass("jscolor");
				$("#slogan_text_2_color").addClass("jscolor");
				$("#slogan_text_3_color").addClass("jscolor");
				$("#header_bar_color").addClass("jscolor");
				$("#sidemenu_background_color").addClass("jscolor");
				$("#sidemenu_text_color").addClass("jscolor");

				$("#layouts").css("max-height","none").css("width","100%").css("padding-top","20px");
				$(".jscolor").each(function() {
					var el = $(this);
					var mainColor = el.val();
					el.css("backgroundColor", el.val());
					 el.ColorPicker({
						color: el.val(),
						onChange: function (hsb, hex, rgb) {
							el.css("backgroundColor", "#" + hex);
							el.val("#" + hex);
						}
					});
				});				
			</script>
			
		');
		
		$this->addNav("submit", __("Save"), false, false);
		self::addClass("btn-sm", $this->getDisplayGroup("submit")->getElement(__("Save")));

    }

	public function populate($values)
	{
		//Default settings
		if (!isset($values["slogan_text_1"]))  $values["slogan_text_1"]="Premium B"; 
		if (!isset($values["slogan_text_2"]))  $values["slogan_text_2"]="App Layout"; 
		if (!isset($values["slogan_text_3"]))  $values["slogan_text_3"]="Premium B"; 
		if (!isset($values["header_background_color"]))  $values["header_background_color"]="#FC5241";
		if (!isset($values["header_title_top_color"]))  $values["header_title_top_color"]="#c04c4c";
		if (!isset($values["header_title_bottom_color"]))  $values["header_title_bottom_color"]="#c04c4c";
		if (!isset($values["slogan_text_1_color"]))  $values["slogan_text_1_color"]="#e0e0e0";
		if (!isset($values["slogan_text_2_color"]))  $values["slogan_text_2_color"]="#e0e0e0";
		if (!isset($values["slogan_text_3_color"]))  $values["slogan_text_3_color"]="#FFFFFF";
		if (!isset($values["menu_button_class"]))  $values["menu_button_class"]="ion-navicon-round";
		if (!isset($values["header_bar_color"]))  $values["header_bar_color"]="#FFFFFF";
		if (!isset($values["sidemenu_background_color"]))  $values["sidemenu_background_color"]="#333333";
		if (!isset($values["sidemenu_text_color"]))  $values["sidemenu_text_color"]="#f0f0f0";
		if (!isset($values["sidemenu_header_text"]))  $values["sidemenu_header_text"]="<strong>Premium B Menu</strong>"; else $values["sidemenu_header_text"]=base64_decode($values["sidemenu_header_text"]);
		if (!isset($values["sidemenu_text_font_size"]))  $values["sidemenu_text_font_size"]="14px";
		if (!isset($values["show_account_icon"]))  $values["show_account_icon"]="yes";
		if (!isset($values["show_account_icon_class_unlogged"]))  $values["show_account_icon_class_unlogged"]="ion-locked";
		if (!isset($values["show_account_icon_class_logged"]))  $values["show_account_icon_class_logged"]="ion-person";
		if (!isset($values["show_wallet_icon_class"]))  $values["show_wallet_icon_class"]="ion-card";
		if (!isset($values["show_wallet_icon"]))  $values["show_wallet_icon"]="yes";
		

		
		
		parent::populate($values);
	}
	
	public function addColorPicker($name, $title, $value)
	{
	$color_html = '
<div>
 <div class="col-md-12 layout-colorpicker">
     <div class="colorlabel"><b>'.__($title).': </b></div>
     <div class="colorpicker-block col-sm-12">
         <div class="colorpicker-square"></div>
         <input type="text" class="colorpicker-input input-flat" name="' . $name . '" id="android_push_color" value="' . $value . '" />
     </div>
 </div>
</div>
	';

	$this->addSimpleHtml($name, $color_html);

	return $this;
	}	

  public function addSectionSeparator($name)
  {
    $html = '
			<div class="form-group sb-form-line ">
				<div class="col-sm-12 text-center">
					<h2>'.$name.'</h2>
					<hr>
				</div>
			</div>
	
	';
	//$html = '<br/><h4>'.$name.'</h4><hr/>';
    $this->addSimpleHtml($name, $html);

    return $this;
  }
  
   public function addStartFieldset($name)
  {
    $html = '<fieldset id='.$name.'>';
    $this->addSimpleHtml($name, $html);
    return $this;
  }
   public function addEndFieldset($name)
  {
    $html = '</fieldse>';
    $this->addSimpleHtml($name, $html);
    return $this;
  }  
}

?>