App.service('layout_premium_b', function ($rootScope, HomepageLayout) {

    var service = {};

    /**
     * Must return a valid template
     *
     * @returns {string}
     */
    service.getTemplate = function() {
        return "modules/layout/home/layout_premium_b/view.html";
    };

    /**
     * Must return a valid template
     *
     * @returns {string}
     */
    service.getModalTemplate = function() {
        return "templates/home/l10/modal.html";
    };

    /**
     * onResize is used for css/js callbacks when orientation change
     */
    service.onResize = function() {
        /** Do nothing for this particular one */
    };

    /**
     * Manipulate the features objects
     *
     * Examples:
     * - you can re-order features
     * - you can push/place the "more_button"
     *
     * @param features
     * @param more_button
     * @returns {*}
     */
    service.features = function(features, more_button) {
        /** Place more button at the end */
        //features.overview.options.push(more_button);

        return features;
    };

    return service;

});

App.controller('agc241templatecontroller', function($scope,Url,$ionicSideMenuDelegate,$ionicScrollDelegate, $ionicPosition, $rootScope, $timeout, $translate, $location, $compile, $sce, $window, Application, Customer,   Dialog,  HomepageLayout, $log,$pwaRequest)
{
	console.log("Layout Premium B start");
	$scope.options = {};
	$scope.is_loading = true;
	$scope.title_rich = "";
	$scope.has_header = false;
	$scope.pointer_events = "none";
	$scope.wallet_score = 0;
	$scope.wallet_option = {};
	$scope.wallet = {};
	$scope.wallet_found = false;
	$scope.is_logged_in = Customer.isLoggedIn();
	HomepageLayout.getFeatures().then(function(features) {
		console.log(features);
		$scope.options = features.layoutOptions;
		console.log("Layout Premium B options:");
		console.log($scope.options);
		$scope.is_loading = false;
		document.getElementById('layout_premium_b_top_logo').style.borderTopColor = $scope.convertHex($scope.options.header_title_top_color,30);
		document.getElementById('layout_premium_b_top_logo').style.borderBottomColor = $scope.convertHex($scope.options.header_title_bottom_color,30);
		
		
		//Включим опции и значки
		features.options.forEach(function(element) {
			//Кошелек
			if ($scope.options.show_wallet_icon=="yes" && element.code=="wallet") {
				$scope.wallet_option = element;
				$scope.wallet_found = true;
				$scope.wallet =  $pwaRequest.get("wallet/mobile_view/find", { urlParams: { value_id: element.id }, cache: false, refresh: true });
				console.log("Wallet found in maket:");
				console.log($scope.wallet);
			}
		});		



		
	});
	
	$scope.getScrollPosition = function(){
		var sh = $ionicScrollDelegate.$getByHandle('scrollhandler').getScrollPosition().top;
		/*if (sh==0) {sh=100;$scope.has_header = false; }
		else if (sh<=20 && sh>0) {sh = 100-sh*4; $scope.has_header=false;}	//прозрачность титла
		else {sh=0; $scope.has_header=true;}
		document.getElementById('layout_premium_b_top_logo').style.opacity = sh/100;*/
		
		// top border
		if (sh<6) document.getElementById('layout_premium_b_top_logo').style.borderTopColor = $scope.convertHex($scope.options.header_title_top_color,30-sh*5); else document.getElementById('layout_premium_b_top_logo').style.borderTopColor = $scope.convertHex($scope.options.header_title_top_color,0);
		
		//h1
		if (sh<11) document.getElementById('layout_premium_b_top_logo_h1').style.opacity = (100 - sh*10)/100 ; else document.getElementById('layout_premium_b_top_logo_h1').style.opacity = 0;
		
		//h2
		if (sh<=11) document.getElementById('layout_premium_b_top_logo_h2').style.opacity = 1 ;
		if (sh>11 && sh<56) document.getElementById('layout_premium_b_top_logo_h2').style.opacity = (100 - sh*2)/100 ;
		if (sh>=56) document.getElementById('layout_premium_b_top_logo_h2').style.opacity = 0 ;
		
		//bottom border
		if (sh<=56) document.getElementById('layout_premium_b_top_logo').style.borderBottomColor = $scope.convertHex($scope.options.header_title_bottom_color,30);
		if (sh>=56) document.getElementById('layout_premium_b_top_logo').style.borderBottomColor = $scope.convertHex($scope.options.header_title_bottom_color,30-(sh-56)*5);
		
		//top title
		if (sh>=40) document.getElementById('layout_premium_b_header_title').style.opacity = (sh-30)/100;  else document.getElementById('layout_premium_b_header_title').style.opacity = 0;
		
		
		
		
		console.log("Scroll Event:");
		console.log($ionicScrollDelegate.$getByHandle('scrollhandler').getScrollPosition().top);
		
		//triangle
		if (sh==0) document.getElementById('anum-svg').style.bottom = "-30px"; else document.getElementById('anum-svg').style.bottom = "-"+((30-sh/2)).toString()+"px";
	}
	
	$scope.mb64toutf = function(str64) {
		console.log(str64);
		return decodeURIComponent(atob(str64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
		}).join(''));
	};

	$scope.convertHex = function (hex,opacity){
		hex = hex.replace('#','');
		r = parseInt(hex.substring(0,2), 16);
		g = parseInt(hex.substring(2,4), 16);
		b = parseInt(hex.substring(4,6), 16);

		result = 'rgba('+r+','+g+','+b+','+opacity/100+')';
		return result;
	}	
	
	$scope.toggleLeft = function() {
		$ionicSideMenuDelegate.$getByHandle('menu-layout').toggleLeft();
			$scope.pointer_events = "none";
			$timeout( function(){
				$scope.is_open_menu = true;			
				$scope.pointer_events = "auto";
				var ratio = $ionicSideMenuDelegate.$getByHandle('menu-layout').getOpenRatio();
				console.log(ratio);
			}, 400 );		
	};
	
	$scope.trustAsHtml = function(string) {
		return $sce.trustAsHtml(string);
	};
	
	$scope.clickLogin = function() {
		Customer.loginModal();
	};
	
  $scope.updateScopeOnAuthEvent = function() {
    $scope.is_loading = true;
	console.log("$scope.updateScopeOnAuthEvent:");
	console.log(Customer.isLoggedIn());
	if (Customer.isLoggedIn()) {
		Customer.find().then(function(customer) {
			console.log("$scope.updateScopeOnAuthEvent found customer:");
			console.log(customer);
			$scope.customer = customer;
			$scope.avatar_url = Customer.getAvatarUrl($scope.customer.id);
			console.log("$scope.updateScopeOnAuthEvent avatar_url:"+$scope.avatar_url);
			$scope.is_logged_in = true;
		})
		.then(function() {
			$scope.is_loading = false;
			$scope.is_logged_in = true;
		});		
	} else {
		$scope.customer = {};
		$scope.is_logged_in = false;
		$scope.is_loading = false;
	}
  }

	
	$rootScope.$on("auth-login-success", function() {
		console.log("LayoutPremiumB catch event: auth-login-success");
		$scope.updateScopeOnAuthEvent();
	});

	$rootScope.$on("auth-logout-success", function() {
		console.log("LayoutPremiumB catch event: auth-logout-success");
		$scope.updateScopeOnAuthEvent();
	});

	$rootScope.$on("auth-register-success", function() {
		console.log("LayoutPremiumB catch event: auth-register-success");
		$scope.updateScopeOnAuthEvent();
	});	
	
	$scope.openFeature = function(feature_id) {
		console.log("openFeature clicked:");
		if (feature_id!="") {
			if(typeof $scope.features.overview.options[feature_id] === 'undefined') {
			// does not exist
			} else {
				// does exist
				HomepageLayout.openFeature($scope.features.overview.options[feature_id], $scope);
			}	

		}

	};
  
});
