/*global
 App, angular, BASE_PATH
 */
angular.module("starter").controller("WalletViewController", function ($log, $sce, $scope, $stateParams, $timeout, Wallet,Loader,Customer) {
    angular.extend($scope, {
        is_loading  : true,
        value_id    : $stateParams.value_id
    });
    
	console.log("WalletViewController fired");
	
	$scope.value_id = $stateParams.value_id;
	Wallet.value_id= $stateParams.value_id;
	$scope.page_title = "";
	$scope.customer_name = "";
	$scope.customer_email = "";
	$scope.html_string = "";
	$scope.is_loading = true;
	Loader.show();

    
	$scope.loadContent = function () {
		console.log("Wallet loadContent.");
		Wallet.find().then(function (data) {
			console.log("Wallet.find:");
			console.log(data);
			//$scope.is_loading = false;
			//Loader.hide();			
	
			
		}).then(function () {
			$scope.is_loading = false;
			Loader.hide();
		});
			
    };
    
	$scope.loadContent();

});