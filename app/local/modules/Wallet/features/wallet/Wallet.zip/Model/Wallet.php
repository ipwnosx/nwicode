<?php

/**
 * Class Wallet_Model_Wallet
 *
 */
class Wallet_Model_Wallet extends Core_Model_Default
{
    /**
     * Wallet_Model_Wallet constructor.
     * @param array $params
     */
    public function __construct($params = [])
    {
        parent::__construct($params);
        $this->_db_table = 'Wallet_Model_Db_Table_Wallet';
        return $this;
    }
}
