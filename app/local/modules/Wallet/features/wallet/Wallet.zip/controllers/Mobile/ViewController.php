<?php

class Wallet_Mobile_ViewController extends Application_Controller_Mobile_Default {


    public function findAction() {

		$data['dd']="1";
        if($value_id = $this->getRequest()->getParam('value_id')) {

            try {
			
				$option = $this->getCurrentOptionValue();
				$wallet = (new Wallet_Model_Wallet())->find(["value_id" => $value_id]);
				$customer = $this->getSession()->getCustomer();

					
			
		
                $data = array(
                    "chat" => $chat->getData(),
					"customer" =>$customer->getData()
                );
            }
            catch(Exception $e) {
                $data = array('error' => 1, 'message' => $e->getMessage());
            }

        }else{
            $data = array('error' => 1, 'message' => 'An error occurred during process. Please try again later.');
        }

        $this->_sendHtml($data);

    }

}