<?php

class Wallet_ApplicationController extends Application_Controller_Default
{

    public function loadtabAction() {

        try {

            if($tab_id = $this->getRequest()->getParam('tab_id')) {

                $html = $this->getLayout()->addPartial('tab_html', 'admin_view_default', 'wallet/application/'.$tab_id.'.phtml')
                    ->setOptionValue($this->getCurrentOptionValue())
                    ->toHtml()
                ;
                $html = array('tab_html' => $html);

            }
            else {
                throw new Exception($this->_('An error occurred during the process. Please try again later.'));
            }

        }
        catch(Exception $e) {
            $html = array(
                'error' => 1,
                'message' => $e->getMessage(),
                'message_button' => 1,
                'message_loader' => 1
            );
        }

        $this->_sendHtml($html);

    }

    public function viewAction() {
        $this->loadPartials();
    }

    public function loadAction(){
        $payload = [
            'title' => __('Wallet'),
            'icon' => 'fa-cogs',
        ];

        $this->_sendJson($payload);
    }

    public function editpostAction()
    {
        $request = $this->getRequest();
        $values = $request->getPost();

        try {

			$optionValue = $this->getCurrentOptionValue();

			$wallet = (new Wallet_Model_Wallet())
				->find($values['value_id'], 'value_id');

			$wallet->setData($values);


			$wallet->save();



			$payload = [
                  'success' => '1',
                    'success_message' => $this->_('Info successfully saved'),
                    'message_timeout' => 2,
                    'message_button' => 0,
                    'message_loader' => 0
			];

        } catch (Exception $e) {
            $payload = [
                'error' => true,
                'message' => $e->getMessage()
            ];
        }

        $this->_sendJson($payload);
    }
	
}